//
//  OoyalaTVSkinSDK.h
//  OoyalaTVSkinSDK
//
//  Created by Zhihui Chen on 5/9/16.
//  Copyright © 2016 ooyala. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OoyalaTVSkinSDK.
FOUNDATION_EXPORT double OoyalaTVSkinSDKVersionNumber;

//! Project version string for OoyalaTVSkinSDK.
FOUNDATION_EXPORT const unsigned char OoyalaTVSkinSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OoyalaTVSkinSDK/PublicHeader.h>


